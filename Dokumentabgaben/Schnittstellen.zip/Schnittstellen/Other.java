package swp.bibcommon;

import java.io.Serializable;

/**
 * Attribute der Klasse Sonstiges
 * @author Pupat
 *
 */
public class Other extends Medium implements Serializable{
	/**
	 * Autorenliste
	 */
	private String Autorenliste;
	
	/**
	 * Hersteller
	 */
	private String producer;

}
