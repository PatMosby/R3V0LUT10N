var classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4 =
[
    [ "BusinessObjectHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a309702ca1276e607ac310a26b58d8bce", null ],
    [ "add", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#aa4be3c755f057c82a9f05554bd61cd64", null ],
    [ "delete", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a3ea821e0e980930208b38057ed4025fe", null ],
    [ "exportCSV", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#ab09300a8c239fafe82750ad4394dec43", null ],
    [ "get", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a4855cd59d53cd8a03d77a7c5c856b754", null ],
    [ "get", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a3fad50d1106c7c13c396b38811f94c89", null ],
    [ "getNumber", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a69275c12f112f6487f8e795f62ae8609", null ],
    [ "getPrototype", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a4cb8a516a02d0734036202fdb6186946", null ],
    [ "importCSV", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#ae00b3b55684cf9b698d07793a754da94", null ],
    [ "update", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html#a2f7f958457e199f8076f0d15d8b4c481", null ]
];