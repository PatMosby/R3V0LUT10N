var dir_4dd6645d97bf1c8a11ec3c75dbcf7b3b =
[
    [ "bibclient", "dir_51f975cfc8a2a82dcf420068fe42ccbd.html", "dir_51f975cfc8a2a82dcf420068fe42ccbd" ]
];