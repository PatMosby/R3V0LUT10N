var classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content =
[
    [ "BookTagContent", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content.html#a0f648a55d84a46396a48fba5efa5e9a3", null ],
    [ "firstLine", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content.html#a280fa255467056accdd3a95571334dab", null ],
    [ "ID", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content.html#a73e90baa40a3ef9f27e7b925d4bdb94e", null ],
    [ "secondLine", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content.html#a2061c33f5306560d6eb97eeb8a082f13", null ]
];