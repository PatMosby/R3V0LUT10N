var classswp_1_1bibjsf_1_1exception_1_1_book_already_exists_exception =
[
    [ "BookAlreadyExistsException", "classswp_1_1bibjsf_1_1exception_1_1_book_already_exists_exception.html#a75aebc76efee2541e8b86a6768d7453a", null ],
    [ "BookAlreadyExistsException", "classswp_1_1bibjsf_1_1exception_1_1_book_already_exists_exception.html#a84f34d2fe05e5388626c13199ec3aaa4", null ]
];