var classswp_1_1bibjsf_1_1_config =
[
    [ "init", "classswp_1_1bibjsf_1_1_config.html#a6212ef69390549d9955b125e88d16c13", null ]
];