var classswp_1_1bibjsf_1_1presentation_1_1_book_table =
[
    [ "BookTable", "classswp_1_1bibjsf_1_1presentation_1_1_book_table.html#a2e2c08e9a79fe68637ade307bc5646a5", null ],
    [ "getContent", "classswp_1_1bibjsf_1_1presentation_1_1_book_table.html#a0004908f913ec6c589c4c3361cd6bc86", null ],
    [ "getPrinter", "classswp_1_1bibjsf_1_1presentation_1_1_book_table.html#a81968267f2d59d529b5aec7c823886f0", null ]
];