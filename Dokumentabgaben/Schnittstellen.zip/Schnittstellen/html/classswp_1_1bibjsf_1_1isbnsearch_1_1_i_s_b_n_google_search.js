var classswp_1_1bibjsf_1_1isbnsearch_1_1_i_s_b_n_google_search =
[
    [ "ISBNGoogleSearch", "classswp_1_1bibjsf_1_1isbnsearch_1_1_i_s_b_n_google_search.html#a0baeca4a7ecac9bb0c1e68e309e1c874", null ],
    [ "search", "classswp_1_1bibjsf_1_1isbnsearch_1_1_i_s_b_n_google_search.html#a19c735950ecde383921bc2603bebbab1", null ],
    [ "searchByIndustrialIdentifier", "classswp_1_1bibjsf_1_1isbnsearch_1_1_i_s_b_n_google_search.html#a3dbdaf0b0d98d547d98f2364d36dd09f", null ]
];