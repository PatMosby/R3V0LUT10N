var dir_51f975cfc8a2a82dcf420068fe42ccbd =
[
    [ "AsyncMediumTask.java", "_async_medium_task_8java.html", [
      [ "AsyncMediumTask", "classswp_1_1bibclient_1_1_async_medium_task.html", "classswp_1_1bibclient_1_1_async_medium_task" ]
    ] ],
    [ "EarmarkActivity.java", "_earmark_activity_8java.html", [
      [ "EarmarkActivity", "classswp_1_1bibclient_1_1_earmark_activity.html", "classswp_1_1bibclient_1_1_earmark_activity" ]
    ] ],
    [ "ListMediumActivity.java", "_list_medium_activity_8java.html", [
      [ "ListMediumActivity", "classswp_1_1bibclient_1_1_list_medium_activity.html", "classswp_1_1bibclient_1_1_list_medium_activity" ]
    ] ],
    [ "LoginActivity.java", "_login_activity_8java.html", [
      [ "LoginActivity", "classswp_1_1bibclient_1_1_login_activity.html", "classswp_1_1bibclient_1_1_login_activity" ]
    ] ],
    [ "LoginHttpClient.java", "_login_http_client_8java.html", [
      [ "LoginHttpClient", "classswp_1_1bibclient_1_1_login_http_client.html", null ]
    ] ],
    [ "MainActivity.java", "_main_activity_8java.html", [
      [ "MainActivity", "classswp_1_1bibclient_1_1_main_activity.html", "classswp_1_1bibclient_1_1_main_activity" ]
    ] ],
    [ "MainActivityGuest.java", "_main_activity_guest_8java.html", [
      [ "MainActivityGuest", "classswp_1_1bibclient_1_1_main_activity_guest.html", "classswp_1_1bibclient_1_1_main_activity_guest" ]
    ] ],
    [ "MediumAdapter.java", "_medium_adapter_8java.html", [
      [ "MediumAdapter", "classswp_1_1bibclient_1_1_medium_adapter.html", "classswp_1_1bibclient_1_1_medium_adapter" ]
    ] ],
    [ "Network.java", "_network_8java.html", [
      [ "Network", "classswp_1_1bibclient_1_1_network.html", "classswp_1_1bibclient_1_1_network" ]
    ] ],
    [ "ShowBookActivity.java", "_show_book_activity_8java.html", [
      [ "ShowBookActivity", "classswp_1_1bibclient_1_1_show_book_activity.html", "classswp_1_1bibclient_1_1_show_book_activity" ]
    ] ],
    [ "ShowImpressumActivity.java", "_show_impressum_activity_8java.html", [
      [ "ShowImpressumActivity", "classswp_1_1bibclient_1_1_show_impressum_activity.html", "classswp_1_1bibclient_1_1_show_impressum_activity" ]
    ] ],
    [ "ShowLeasedMediumActivity.java", "_show_leased_medium_activity_8java.html", [
      [ "ShowLeasedMediumActivity", "classswp_1_1bibclient_1_1_show_leased_medium_activity.html", "classswp_1_1bibclient_1_1_show_leased_medium_activity" ]
    ] ],
    [ "ShowMediumDetailedActivity.java", "_show_medium_detailed_activity_8java.html", [
      [ "ShowMediumDetailedActivity", "classswp_1_1bibclient_1_1_show_medium_detailed_activity.html", "classswp_1_1bibclient_1_1_show_medium_detailed_activity" ]
    ] ],
    [ "ShowUserInfoActivity.java", "_show_user_info_activity_8java.html", [
      [ "ShowUserInfoActivity", "classswp_1_1bibclient_1_1_show_user_info_activity.html", "classswp_1_1bibclient_1_1_show_user_info_activity" ]
    ] ]
];