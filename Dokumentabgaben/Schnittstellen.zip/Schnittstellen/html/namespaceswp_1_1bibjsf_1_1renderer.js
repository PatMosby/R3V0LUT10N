var namespaceswp_1_1bibjsf_1_1renderer =
[
    [ "BookTagContent", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content.html", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content" ],
    [ "BookTagPrinter", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer.html", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer" ],
    [ "Content", "interfaceswp_1_1bibjsf_1_1renderer_1_1_content.html", null ],
    [ "IDCardPrinter", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer.html", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer" ],
    [ "IDContent", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content" ],
    [ "Printer", "classswp_1_1bibjsf_1_1renderer_1_1_printer.html", "classswp_1_1bibjsf_1_1renderer_1_1_printer" ]
];