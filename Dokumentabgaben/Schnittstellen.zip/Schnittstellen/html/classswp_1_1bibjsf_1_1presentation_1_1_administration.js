var classswp_1_1bibjsf_1_1presentation_1_1_administration =
[
    [ "backupDB", "classswp_1_1bibjsf_1_1presentation_1_1_administration.html#a40a1549cb54d33232598479f942b54e2", null ],
    [ "resetDB", "classswp_1_1bibjsf_1_1presentation_1_1_administration.html#a710bc900c7829132ac2ced7c82182d87", null ],
    [ "restoreDB", "classswp_1_1bibjsf_1_1presentation_1_1_administration.html#a1673af04603bc42946fa97178395d33e", null ]
];