var dir_588832c69b32ac6cf4b8951f0f9c45fb =
[
    [ "BookTagPrinterTest.java", "_book_tag_printer_test_8java.html", [
      [ "BookTagPrinterTest", "classswp_1_1bibjsf_1_1tests_1_1_book_tag_printer_test.html", "classswp_1_1bibjsf_1_1tests_1_1_book_tag_printer_test" ]
    ] ],
    [ "CSVReaderTest.java", "_c_s_v_reader_test_8java.html", [
      [ "CSVReaderTest", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test" ]
    ] ],
    [ "IDCardPrinterTest.java", "_i_d_card_printer_test_8java.html", [
      [ "IDCardPrinterTest", "classswp_1_1bibjsf_1_1tests_1_1_i_d_card_printer_test.html", "classswp_1_1bibjsf_1_1tests_1_1_i_d_card_printer_test" ]
    ] ],
    [ "ISBNGoogleSearchTest.java", "_i_s_b_n_google_search_test_8java.html", [
      [ "ISBNGoogleSearchTest", "classswp_1_1bibjsf_1_1tests_1_1_i_s_b_n_google_search_test.html", "classswp_1_1bibjsf_1_1tests_1_1_i_s_b_n_google_search_test" ]
    ] ],
    [ "package-info.java", "bibjsf_2src_2test_2java_2swp_2bibjsf_2tests_2package-info_8java.html", null ]
];