var classswp_1_1bibjsf_1_1presentation_1_1_add_book_form =
[
    [ "AddBookForm", "classswp_1_1bibjsf_1_1presentation_1_1_add_book_form.html#addaad34f2a02d76afd7e34b905ca43ac", null ],
    [ "reset", "classswp_1_1bibjsf_1_1presentation_1_1_add_book_form.html#a75ed284cc6597dc7feda744f0a440e0f", null ],
    [ "save", "classswp_1_1bibjsf_1_1presentation_1_1_add_book_form.html#a652485b9fedc25db75aeb7ae3ccdabfd", null ]
];