var classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler =
[
    [ "BookHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#ad9c40f515c549d1e923637857aeef29e", null ],
    [ "add", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a6dce6cd1692fb8ad339975a3db8440b2", null ],
    [ "delete", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a4a3b2cb251e642ea0968091f9ca7c840", null ],
    [ "exportCSV", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#ad6b40bf922433d468c44f3bbcb94d751", null ],
    [ "get", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a651b407994102c31e79c6c14cc3c48ba", null ],
    [ "get", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#acc9e68636004cdcd139dd0865db5a314", null ],
    [ "getAllBooks", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#ae93e4fca81959cb831e0acd6900e2f5a", null ],
    [ "getByIndustrialIdentifier", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#aefe2cbf430d271cd9b47d0560c1006d8", null ],
    [ "getNumber", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a2812ea362b0d0f52f393c4e119348f22", null ],
    [ "getPrototype", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a2a137f613a76d258527fd31f8f696911", null ],
    [ "importCSV", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a4df9bda0ef28fcb18cec9c75946aace6", null ],
    [ "update", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a18a453aae7cb7630d45812916e9c4c99", null ],
    [ "update", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html#a9f5de40bee8cbff50cbd85fa18399994", null ]
];