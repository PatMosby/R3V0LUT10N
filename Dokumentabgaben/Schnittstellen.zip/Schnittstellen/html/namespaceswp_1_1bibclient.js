var namespaceswp_1_1bibclient =
[
    [ "BuildConfig", "classswp_1_1bibclient_1_1_build_config.html", null ],
    [ "R", "classswp_1_1bibclient_1_1_r.html", null ],
    [ "AsyncMediumTask", "classswp_1_1bibclient_1_1_async_medium_task.html", "classswp_1_1bibclient_1_1_async_medium_task" ],
    [ "EarmarkActivity", "classswp_1_1bibclient_1_1_earmark_activity.html", "classswp_1_1bibclient_1_1_earmark_activity" ],
    [ "ListMediumActivity", "classswp_1_1bibclient_1_1_list_medium_activity.html", "classswp_1_1bibclient_1_1_list_medium_activity" ],
    [ "LoginActivity", "classswp_1_1bibclient_1_1_login_activity.html", "classswp_1_1bibclient_1_1_login_activity" ],
    [ "LoginHttpClient", "classswp_1_1bibclient_1_1_login_http_client.html", null ],
    [ "MainActivity", "classswp_1_1bibclient_1_1_main_activity.html", "classswp_1_1bibclient_1_1_main_activity" ],
    [ "MainActivityGuest", "classswp_1_1bibclient_1_1_main_activity_guest.html", "classswp_1_1bibclient_1_1_main_activity_guest" ],
    [ "MediumAdapter", "classswp_1_1bibclient_1_1_medium_adapter.html", "classswp_1_1bibclient_1_1_medium_adapter" ],
    [ "Network", "classswp_1_1bibclient_1_1_network.html", "classswp_1_1bibclient_1_1_network" ],
    [ "ShowBookActivity", "classswp_1_1bibclient_1_1_show_book_activity.html", "classswp_1_1bibclient_1_1_show_book_activity" ],
    [ "ShowImpressumActivity", "classswp_1_1bibclient_1_1_show_impressum_activity.html", "classswp_1_1bibclient_1_1_show_impressum_activity" ],
    [ "ShowLeasedMediumActivity", "classswp_1_1bibclient_1_1_show_leased_medium_activity.html", "classswp_1_1bibclient_1_1_show_leased_medium_activity" ],
    [ "ShowMediumDetailedActivity", "classswp_1_1bibclient_1_1_show_medium_detailed_activity.html", "classswp_1_1bibclient_1_1_show_medium_detailed_activity" ],
    [ "ShowUserInfoActivity", "classswp_1_1bibclient_1_1_show_user_info_activity.html", "classswp_1_1bibclient_1_1_show_user_info_activity" ]
];