var dir_c8e1704304ee38ea954f607c806ca574 =
[
    [ "BibServices.java", "_bib_services_8java.html", [
      [ "BibServices", "classswp_1_1bibjsf_1_1services_1_1_bib_services.html", "classswp_1_1bibjsf_1_1services_1_1_bib_services" ]
    ] ],
    [ "package-info.java", "bibjsf_2src_2main_2java_2swp_2bibjsf_2services_2package-info_8java.html", null ]
];