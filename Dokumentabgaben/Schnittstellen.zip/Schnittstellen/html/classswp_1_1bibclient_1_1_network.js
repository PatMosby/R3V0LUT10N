var classswp_1_1bibclient_1_1_network =
[
    [ "getMediums", "classswp_1_1bibclient_1_1_network.html#adbf8e1f98df99485665bd9a2db6485f3", null ]
];