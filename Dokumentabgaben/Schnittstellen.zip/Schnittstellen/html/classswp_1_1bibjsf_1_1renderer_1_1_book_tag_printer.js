var classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer =
[
    [ "numberOfCardsPerColumn", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer.html#a26f0a3a0f30b96c5094682597ff58c17", null ],
    [ "numberOfCardsPerRow", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer.html#a4414c04602329270a80c82c8c81eadb7", null ],
    [ "printCard", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer.html#a97fca4cfbd60dfb0deb1446ba1a9e954", null ]
];