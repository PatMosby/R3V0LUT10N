var classswp_1_1bibclient_1_1_main_activity_guest =
[
    [ "onCreate", "classswp_1_1bibclient_1_1_main_activity_guest.html#a2b4d19e7f837b96cf363bb126e05bf88", null ]
];