var namespaceswp_1_1bibjsf_1_1isbnsearch =
[
    [ "GoogleAPIKey", "classswp_1_1bibjsf_1_1isbnsearch_1_1_google_a_p_i_key.html", null ],
    [ "ISBNGoogleSearch", "classswp_1_1bibjsf_1_1isbnsearch_1_1_i_s_b_n_google_search.html", "classswp_1_1bibjsf_1_1isbnsearch_1_1_i_s_b_n_google_search" ]
];