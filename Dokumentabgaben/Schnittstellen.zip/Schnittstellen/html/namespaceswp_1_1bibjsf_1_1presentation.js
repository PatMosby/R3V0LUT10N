var namespaceswp_1_1bibjsf_1_1presentation =
[
    [ "AddBookForm", "classswp_1_1bibjsf_1_1presentation_1_1_add_book_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_add_book_form" ],
    [ "AddLibrarianForm", "classswp_1_1bibjsf_1_1presentation_1_1_add_librarian_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_add_librarian_form" ],
    [ "AddReaderForm", "classswp_1_1bibjsf_1_1presentation_1_1_add_reader_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_add_reader_form" ],
    [ "Administration", "classswp_1_1bibjsf_1_1presentation_1_1_administration.html", "classswp_1_1bibjsf_1_1presentation_1_1_administration" ],
    [ "AuthBackingBean", "classswp_1_1bibjsf_1_1presentation_1_1_auth_backing_bean.html", "classswp_1_1bibjsf_1_1presentation_1_1_auth_backing_bean" ],
    [ "BookForm", "classswp_1_1bibjsf_1_1presentation_1_1_book_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_book_form" ],
    [ "BookListDataModel", "classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model.html", "classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model" ],
    [ "BookTable", "classswp_1_1bibjsf_1_1presentation_1_1_book_table.html", "classswp_1_1bibjsf_1_1presentation_1_1_book_table" ],
    [ "BusinessObjectForm< Element extends BusinessObject >", "classswp_1_1bibjsf_1_1presentation_1_1_business_object_form_3_01_element_01extends_01_business_object_01_4.html", "classswp_1_1bibjsf_1_1presentation_1_1_business_object_form_3_01_element_01extends_01_business_object_01_4" ],
    [ "ChangeBookForm", "classswp_1_1bibjsf_1_1presentation_1_1_change_book_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_change_book_form" ],
    [ "ChangeReaderForm", "classswp_1_1bibjsf_1_1presentation_1_1_change_reader_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_change_reader_form" ],
    [ "ReaderForm", "classswp_1_1bibjsf_1_1presentation_1_1_reader_form.html", "classswp_1_1bibjsf_1_1presentation_1_1_reader_form" ],
    [ "ReaderTable", "classswp_1_1bibjsf_1_1presentation_1_1_reader_table.html", "classswp_1_1bibjsf_1_1presentation_1_1_reader_table" ],
    [ "TableDataModel< Element extends BusinessObject >", "classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4.html", "classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4" ],
    [ "TableForm< Element extends BusinessObject >", "classswp_1_1bibjsf_1_1presentation_1_1_table_form_3_01_element_01extends_01_business_object_01_4.html", "classswp_1_1bibjsf_1_1presentation_1_1_table_form_3_01_element_01extends_01_business_object_01_4" ]
];