var classswp_1_1bibcommon_1_1_other =
[
    [ "Other", "classswp_1_1bibcommon_1_1_other.html#ad5bfdb31630848c10c5d1fb5f223d7de", null ],
    [ "Other", "classswp_1_1bibcommon_1_1_other.html#afcc2f069016bb35e9d5d4210a951566d", null ],
    [ "getAutorenliste", "classswp_1_1bibcommon_1_1_other.html#a8dff21112a8f5db17d1a58e1996d3c0a", null ],
    [ "getProducer", "classswp_1_1bibcommon_1_1_other.html#ad77a1682ab034b79c939a3d38f276c25", null ],
    [ "setAutorenliste", "classswp_1_1bibcommon_1_1_other.html#a86c5496e25ae71d06f6ade62e44c5713", null ],
    [ "setProducer", "classswp_1_1bibcommon_1_1_other.html#a2a871a6107269533ae0e073411a46db9", null ]
];