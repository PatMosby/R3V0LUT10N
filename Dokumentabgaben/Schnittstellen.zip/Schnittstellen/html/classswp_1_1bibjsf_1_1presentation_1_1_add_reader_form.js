var classswp_1_1bibjsf_1_1presentation_1_1_add_reader_form =
[
    [ "AddReaderForm", "classswp_1_1bibjsf_1_1presentation_1_1_add_reader_form.html#ae617fb93b187d66a7a0a3b4efbbd16d8", null ],
    [ "reset", "classswp_1_1bibjsf_1_1presentation_1_1_add_reader_form.html#aecfffafac3919d972e1dfa9fc400bbc8", null ],
    [ "save", "classswp_1_1bibjsf_1_1presentation_1_1_add_reader_form.html#a96a5c3317c57a93ab4b0872b491a1265", null ]
];