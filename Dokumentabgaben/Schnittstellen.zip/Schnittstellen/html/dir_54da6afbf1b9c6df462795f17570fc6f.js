var dir_54da6afbf1b9c6df462795f17570fc6f =
[
    [ "businesslogic", "dir_b3ab93465422fdb0d8c014781d9a1ff9.html", "dir_b3ab93465422fdb0d8c014781d9a1ff9" ],
    [ "exception", "dir_beaba700ab56511fca453fd93b88b509.html", "dir_beaba700ab56511fca453fd93b88b509" ],
    [ "isbnsearch", "dir_d79ce801e3a0975fb08f18db80ceeb04.html", "dir_d79ce801e3a0975fb08f18db80ceeb04" ],
    [ "persistence", "dir_27f4fe4d5157cb47b1850a458e154845.html", "dir_27f4fe4d5157cb47b1850a458e154845" ],
    [ "presentation", "dir_29f06c09ff63db9ca966797b08ee8437.html", "dir_29f06c09ff63db9ca966797b08ee8437" ],
    [ "renderer", "dir_70f801704ccb94565721fc740331b940.html", "dir_70f801704ccb94565721fc740331b940" ],
    [ "services", "dir_c8e1704304ee38ea954f607c806ca574.html", "dir_c8e1704304ee38ea954f607c806ca574" ],
    [ "utils", "dir_ecc7bc6016623741042f08fa1e1d995c.html", "dir_ecc7bc6016623741042f08fa1e1d995c" ],
    [ "Config.java", "_config_8java.html", [
      [ "Config", "classswp_1_1bibjsf_1_1_config.html", "classswp_1_1bibjsf_1_1_config" ]
    ] ]
];