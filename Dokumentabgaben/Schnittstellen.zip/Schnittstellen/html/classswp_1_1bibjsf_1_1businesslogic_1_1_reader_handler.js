var classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler =
[
    [ "ReaderHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#a426309be4b3b19aaa7ebb50e910d9377", null ],
    [ "add", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#aa7e88c97d6cd5b38aa413bab8f645dfb", null ],
    [ "addLibrarian", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#a46154a25c0623e3239395dafef083df5", null ],
    [ "delete", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#ad6e6ef07c2ddaeceba100316e94a62f5", null ],
    [ "exportCSV", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#af58f320c884bdf1539ace37aa371b92e", null ],
    [ "get", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#ae1e967911efc233640f0dea32a31e712", null ],
    [ "get", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#ab5dde041cfb7ffbf18d574a786961d1b", null ],
    [ "getNumber", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#ab428dbec8b0e7cabc5f080b370a87d57", null ],
    [ "getPrototype", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#a6dd804f6f51a3e6f5223fc4eca863b1d", null ],
    [ "importCSV", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#a6cb53e747129ad4f3cd13e18466e8124", null ],
    [ "update", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html#ac4ad3272e0b5ffd3c56289ffbf601193", null ]
];