var dir_387d1483f120591b022e71efc77a6eb3 =
[
    [ "BuildConfig.java", "_build_config_8java.html", [
      [ "BuildConfig", "classswp_1_1bibclient_1_1_build_config.html", null ]
    ] ],
    [ "R.java", "_r_8java.html", [
      [ "R", "classswp_1_1bibclient_1_1_r.html", null ]
    ] ]
];