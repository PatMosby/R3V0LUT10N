var dir_e574d15a6d06a2ee35d9b8ad664b1444 =
[
    [ "Audiobook.java", "_audiobook_8java.html", [
      [ "Audiobook", "classswp_1_1bibcommon_1_1_audiobook.html", "classswp_1_1bibcommon_1_1_audiobook" ]
    ] ],
    [ "Book.java", "_book_8java.html", [
      [ "Book", "classswp_1_1bibcommon_1_1_book.html", "classswp_1_1bibcommon_1_1_book" ]
    ] ],
    [ "Buch.java", "_buch_8java.html", [
      [ "Buch", "classswp_1_1bibcommon_1_1_buch.html", "classswp_1_1bibcommon_1_1_buch" ]
    ] ],
    [ "BusinessObject.java", "_business_object_8java.html", [
      [ "BusinessObject", "classswp_1_1bibcommon_1_1_business_object.html", "classswp_1_1bibcommon_1_1_business_object" ]
    ] ],
    [ "Cassette.java", "_cassette_8java.html", [
      [ "Cassette", "classswp_1_1bibcommon_1_1_cassette.html", "classswp_1_1bibcommon_1_1_cassette" ]
    ] ],
    [ "CD.java", "_c_d_8java.html", [
      [ "CD", "classswp_1_1bibcommon_1_1_c_d.html", "classswp_1_1bibcommon_1_1_c_d" ]
    ] ],
    [ "GsonMessageHandler.java", "_gson_message_handler_8java.html", [
      [ "GsonMessageHandler", "classswp_1_1bibcommon_1_1_gson_message_handler.html", "classswp_1_1bibcommon_1_1_gson_message_handler" ]
    ] ],
    [ "IllegalRating.java", "_illegal_rating_8java.html", [
      [ "IllegalRating", "classswp_1_1bibcommon_1_1_illegal_rating.html", "classswp_1_1bibcommon_1_1_illegal_rating" ]
    ] ],
    [ "Magazine.java", "_magazine_8java.html", [
      [ "Magazine", "classswp_1_1bibcommon_1_1_magazine.html", "classswp_1_1bibcommon_1_1_magazine" ]
    ] ],
    [ "Medium.java", "_medium_8java.html", [
      [ "Medium", "classswp_1_1bibcommon_1_1_medium.html", "classswp_1_1bibcommon_1_1_medium" ]
    ] ],
    [ "Movie.java", "_movie_8java.html", [
      [ "Movie", "classswp_1_1bibcommon_1_1_movie.html", "classswp_1_1bibcommon_1_1_movie" ]
    ] ],
    [ "Other.java", "_other_8java.html", [
      [ "Other", "classswp_1_1bibcommon_1_1_other.html", "classswp_1_1bibcommon_1_1_other" ]
    ] ],
    [ "package-info.java", "bibcommon_2src_2main_2java_2swp_2bibcommon_2package-info_8java.html", null ],
    [ "Reader.java", "_reader_8java.html", [
      [ "Reader", "classswp_1_1bibcommon_1_1_reader.html", "classswp_1_1bibcommon_1_1_reader" ]
    ] ],
    [ "Software.java", "_software_8java.html", [
      [ "Software", "classswp_1_1bibcommon_1_1_software.html", "classswp_1_1bibcommon_1_1_software" ]
    ] ]
];