var classswp_1_1bibcommon_1_1_software =
[
    [ "Software", "classswp_1_1bibcommon_1_1_software.html#a3ffae8b26497ce8785c568b2d8d2cc94", null ],
    [ "Software", "classswp_1_1bibcommon_1_1_software.html#af13cc6556d33ffb0b10c6d7d86584ff0", null ],
    [ "getMedia", "classswp_1_1bibcommon_1_1_software.html#a1b54fe7fe2b39d6a75562d23201ab188", null ],
    [ "getPublisher", "classswp_1_1bibcommon_1_1_software.html#ac31a28144ba5e6b1a808ea1c6d26f961", null ],
    [ "setMedia", "classswp_1_1bibcommon_1_1_software.html#a4af1a24419346f144d0b1f718b5c8da9", null ],
    [ "setPublisher", "classswp_1_1bibcommon_1_1_software.html#a12dd3d0761d083473e247a469dff7162", null ]
];