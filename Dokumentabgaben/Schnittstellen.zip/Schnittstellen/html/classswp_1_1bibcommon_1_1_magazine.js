var classswp_1_1bibcommon_1_1_magazine =
[
    [ "Magazine", "classswp_1_1bibcommon_1_1_magazine.html#aef7e5c6d243f4bff0f2d132e14ea3d54", null ],
    [ "Magazine", "classswp_1_1bibcommon_1_1_magazine.html#a32fafabc921233a524e1fadb7f4f631a", null ],
    [ "getEditorList", "classswp_1_1bibcommon_1_1_magazine.html#a102412c61925e7ca361a76711828ff7d", null ],
    [ "getISSN", "classswp_1_1bibcommon_1_1_magazine.html#a6734bda1bfd9453e2555f5c21d78a66c", null ],
    [ "getPageCount", "classswp_1_1bibcommon_1_1_magazine.html#a3e36e8a5dc665059f388a2faaa1bbf67", null ],
    [ "getPreviewLink", "classswp_1_1bibcommon_1_1_magazine.html#ab07d292885028eb817fb5712277fb5a9", null ],
    [ "getPrintType", "classswp_1_1bibcommon_1_1_magazine.html#a1cdbd2531fb0a429b3130c23d5d3b831", null ],
    [ "getPublisher", "classswp_1_1bibcommon_1_1_magazine.html#a8deee6bcd919260c7d806734247c2988", null ],
    [ "setEditorList", "classswp_1_1bibcommon_1_1_magazine.html#a44219e6ca94668259b28958fa2bec890", null ],
    [ "setISSN", "classswp_1_1bibcommon_1_1_magazine.html#a79941770269560dbaeab53ba3bb92219", null ],
    [ "setPageCount", "classswp_1_1bibcommon_1_1_magazine.html#a79db281fbf86de17ce909b6f583353b0", null ],
    [ "setPreviewLink", "classswp_1_1bibcommon_1_1_magazine.html#a494b0e3dc614823d04f2557e211f35eb", null ],
    [ "setPrintType", "classswp_1_1bibcommon_1_1_magazine.html#aeac90a527066540c748d3f4c3cc83230", null ],
    [ "setPublisher", "classswp_1_1bibcommon_1_1_magazine.html#ad82d27e68ab3d825befb2b0f6482a2e1", null ]
];