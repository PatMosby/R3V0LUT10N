var classswp_1_1bibjsf_1_1utils_1_1_order_by =
[
    [ "OrderBy", "classswp_1_1bibjsf_1_1utils_1_1_order_by.html#aea1ac161f1a57e97f4ef31726120893f", null ],
    [ "OrderBy", "classswp_1_1bibjsf_1_1utils_1_1_order_by.html#abd81c49b734edf28df263f0a37427cdc", null ],
    [ "getAttribute", "classswp_1_1bibjsf_1_1utils_1_1_order_by.html#ab357ffff1f522eb206d744430d542e02", null ],
    [ "isAscending", "classswp_1_1bibjsf_1_1utils_1_1_order_by.html#a0bbae90a9cda21c09971de2c16280fe1", null ],
    [ "setAscending", "classswp_1_1bibjsf_1_1utils_1_1_order_by.html#a617de04d1ec2b68c82261920d81f9e18", null ],
    [ "setAttribute", "classswp_1_1bibjsf_1_1utils_1_1_order_by.html#ade23d54f833666ea67186163708cee3e", null ]
];