var classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4 =
[
    [ "TableDataModel", "classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4.html#a4a9edce71951dffe63729aaa4d777d28", null ],
    [ "getRowData", "classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4.html#aa8a81645fc1363a58a1e8a0e28eb0936", null ],
    [ "getRowKey", "classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4.html#a4bd2adf927573639d316f272f752b001", null ],
    [ "load", "classswp_1_1bibjsf_1_1presentation_1_1_table_data_model_3_01_element_01extends_01_business_object_01_4.html#a536021c8a4a44117711f9e736ccf8d49", null ]
];