var classswp_1_1bibjsf_1_1presentation_1_1_auth_backing_bean =
[
    [ "isLoggedIn", "classswp_1_1bibjsf_1_1presentation_1_1_auth_backing_bean.html#aee8635b334cd38ab3f91428e2fdfbd34", null ],
    [ "logout", "classswp_1_1bibjsf_1_1presentation_1_1_auth_backing_bean.html#a0ae1dc0741eca92e8c9ed67634686618", null ]
];