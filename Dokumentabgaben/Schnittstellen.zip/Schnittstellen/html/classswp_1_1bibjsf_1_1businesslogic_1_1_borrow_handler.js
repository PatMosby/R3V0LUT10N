var classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler =
[
    [ "borrowMedium", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#a64f4fd22c8a382ed1c980fb46fc93adb", null ],
    [ "calculateDate", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#af1894fbb20182e05763c0dcf3c60710d", null ],
    [ "calculateFines", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#abca2bd56bdbc4e665c9d6cb227609086", null ],
    [ "getInfo", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#a28c9a3e7fec7128f5be39fb7c156b701", null ],
    [ "isOverdue", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#aec0a61dfb1494faa96051170d2bb649b", null ],
    [ "overdueMediaList", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#a62884cb98d2a88a60b74bfb4a71b3b15", null ],
    [ "setBorrowed", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html#ac3800ac05ffac21297f0558479d467f4", null ]
];