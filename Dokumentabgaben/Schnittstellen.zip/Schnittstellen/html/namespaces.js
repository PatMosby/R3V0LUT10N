var namespaces =
[
    [ "swp", "namespaceswp.html", "namespaceswp" ]
];