var dir_b3ab93465422fdb0d8c014781d9a1ff9 =
[
    [ "AdministrationHandler.java", "_administration_handler_8java.html", [
      [ "AdministrationHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler" ]
    ] ],
    [ "BookHandler.java", "_book_handler_8java.html", [
      [ "BookHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler" ]
    ] ],
    [ "BorrowHandler.java", "_borrow_handler_8java.html", [
      [ "BorrowHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler" ]
    ] ],
    [ "BusinessHandler.java", "_business_handler_8java.html", [
      [ "BusinessHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_handler" ]
    ] ],
    [ "BusinessObjectHandler.java", "_business_object_handler_8java.html", [
      [ "BusinessObjectHandler< BusinessObject >", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4" ]
    ] ],
    [ "package-info.java", "bibjsf_2src_2main_2java_2swp_2bibjsf_2businesslogic_2package-info_8java.html", null ],
    [ "ReaderHandler.java", "_reader_handler_8java.html", [
      [ "ReaderHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler" ]
    ] ]
];