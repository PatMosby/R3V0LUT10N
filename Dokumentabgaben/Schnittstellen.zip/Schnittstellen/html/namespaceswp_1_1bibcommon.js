var namespaceswp_1_1bibcommon =
[
    [ "Audiobook", "classswp_1_1bibcommon_1_1_audiobook.html", "classswp_1_1bibcommon_1_1_audiobook" ],
    [ "Book", "classswp_1_1bibcommon_1_1_book.html", "classswp_1_1bibcommon_1_1_book" ],
    [ "Buch", "classswp_1_1bibcommon_1_1_buch.html", "classswp_1_1bibcommon_1_1_buch" ],
    [ "BusinessObject", "classswp_1_1bibcommon_1_1_business_object.html", "classswp_1_1bibcommon_1_1_business_object" ],
    [ "Cassette", "classswp_1_1bibcommon_1_1_cassette.html", "classswp_1_1bibcommon_1_1_cassette" ],
    [ "CD", "classswp_1_1bibcommon_1_1_c_d.html", "classswp_1_1bibcommon_1_1_c_d" ],
    [ "GsonMessageHandler", "classswp_1_1bibcommon_1_1_gson_message_handler.html", "classswp_1_1bibcommon_1_1_gson_message_handler" ],
    [ "IllegalRating", "classswp_1_1bibcommon_1_1_illegal_rating.html", "classswp_1_1bibcommon_1_1_illegal_rating" ],
    [ "Magazine", "classswp_1_1bibcommon_1_1_magazine.html", "classswp_1_1bibcommon_1_1_magazine" ],
    [ "Medium", "classswp_1_1bibcommon_1_1_medium.html", "classswp_1_1bibcommon_1_1_medium" ],
    [ "Movie", "classswp_1_1bibcommon_1_1_movie.html", "classswp_1_1bibcommon_1_1_movie" ],
    [ "Other", "classswp_1_1bibcommon_1_1_other.html", "classswp_1_1bibcommon_1_1_other" ],
    [ "Reader", "classswp_1_1bibcommon_1_1_reader.html", "classswp_1_1bibcommon_1_1_reader" ],
    [ "Software", "classswp_1_1bibcommon_1_1_software.html", "classswp_1_1bibcommon_1_1_software" ],
    [ "AppTest", "classswp_1_1bibcommon_1_1_app_test.html", "classswp_1_1bibcommon_1_1_app_test" ]
];