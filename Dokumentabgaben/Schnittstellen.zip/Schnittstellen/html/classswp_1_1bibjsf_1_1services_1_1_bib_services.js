var classswp_1_1bibjsf_1_1services_1_1_bib_services =
[
    [ "BibServices", "classswp_1_1bibjsf_1_1services_1_1_bib_services.html#af960fecab28e0ff0cb4892c5d4f73400", null ],
    [ "books", "classswp_1_1bibjsf_1_1services_1_1_bib_services.html#af2662c4abb2034259983703004b7f25b", null ]
];