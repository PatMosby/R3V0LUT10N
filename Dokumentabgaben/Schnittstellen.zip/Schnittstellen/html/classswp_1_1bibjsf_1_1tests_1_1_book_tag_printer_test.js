var classswp_1_1bibjsf_1_1tests_1_1_book_tag_printer_test =
[
    [ "printBookTags", "classswp_1_1bibjsf_1_1tests_1_1_book_tag_printer_test.html#adf6159722fcf8ba2f7561dc55acbddbf", null ]
];