var classswp_1_1bibjsf_1_1renderer_1_1_i_d_content =
[
    [ "IDContent", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html#ad06d4c048f6b785d229ed8622405d2a1", null ],
    [ "IDContent", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html#af18009242d28f870435ccfadecdabbb2", null ],
    [ "barCodeText", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html#ac717e21551eb249ad26b0f1d87da3816", null ],
    [ "firstname", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html#a04467a8c25b84c05b2194f36e176973a", null ],
    [ "lastname", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html#a8f1e1eb3858b13660f66e2cbc11076ef", null ]
];