var classswp_1_1bibclient_1_1_show_medium_detailed_activity =
[
    [ "onCreate", "classswp_1_1bibclient_1_1_show_medium_detailed_activity.html#a792d9d9f03dbe8a48d44fb4e539f5179", null ],
    [ "onResume", "classswp_1_1bibclient_1_1_show_medium_detailed_activity.html#a0e49ecdad692ac2670f5c4db450e0541", null ]
];