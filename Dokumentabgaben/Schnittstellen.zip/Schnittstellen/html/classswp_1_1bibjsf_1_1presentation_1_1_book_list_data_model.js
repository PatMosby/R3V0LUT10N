var classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model =
[
    [ "BookListDataModel", "classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model.html#a3a8e27da595f05502c22b21971a4c058", null ],
    [ "BookListDataModel", "classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model.html#a82dc856354bddd759eedac81a0a6f0a0", null ],
    [ "getRowData", "classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model.html#a21f6b629ea8066ca9bc54cd93c5438ef", null ],
    [ "getRowKey", "classswp_1_1bibjsf_1_1presentation_1_1_book_list_data_model.html#a51ec272af8563dee202bc63f940f8334", null ]
];