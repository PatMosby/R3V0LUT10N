var classswp_1_1bibclient_1_1_main_activity =
[
    [ "onCreate", "classswp_1_1bibclient_1_1_main_activity.html#a677f8494b281aa0eeae6112ed76d55a0", null ]
];