var namespaceswp_1_1bibjsf =
[
    [ "businesslogic", "namespaceswp_1_1bibjsf_1_1businesslogic.html", "namespaceswp_1_1bibjsf_1_1businesslogic" ],
    [ "exception", "namespaceswp_1_1bibjsf_1_1exception.html", "namespaceswp_1_1bibjsf_1_1exception" ],
    [ "isbnsearch", "namespaceswp_1_1bibjsf_1_1isbnsearch.html", "namespaceswp_1_1bibjsf_1_1isbnsearch" ],
    [ "persistence", "namespaceswp_1_1bibjsf_1_1persistence.html", "namespaceswp_1_1bibjsf_1_1persistence" ],
    [ "presentation", "namespaceswp_1_1bibjsf_1_1presentation.html", "namespaceswp_1_1bibjsf_1_1presentation" ],
    [ "renderer", "namespaceswp_1_1bibjsf_1_1renderer.html", "namespaceswp_1_1bibjsf_1_1renderer" ],
    [ "services", "namespaceswp_1_1bibjsf_1_1services.html", "namespaceswp_1_1bibjsf_1_1services" ],
    [ "tests", "namespaceswp_1_1bibjsf_1_1tests.html", "namespaceswp_1_1bibjsf_1_1tests" ],
    [ "utils", "namespaceswp_1_1bibjsf_1_1utils.html", "namespaceswp_1_1bibjsf_1_1utils" ],
    [ "Config", "classswp_1_1bibjsf_1_1_config.html", "classswp_1_1bibjsf_1_1_config" ]
];