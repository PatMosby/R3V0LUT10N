var dir_70f801704ccb94565721fc740331b940 =
[
    [ "BookTagContent.java", "_book_tag_content_8java.html", [
      [ "BookTagContent", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content.html", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_content" ]
    ] ],
    [ "BookTagPrinter.java", "_book_tag_printer_8java.html", [
      [ "BookTagPrinter", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer.html", "classswp_1_1bibjsf_1_1renderer_1_1_book_tag_printer" ]
    ] ],
    [ "Content.java", "_content_8java.html", [
      [ "Content", "interfaceswp_1_1bibjsf_1_1renderer_1_1_content.html", null ]
    ] ],
    [ "IDCardPrinter.java", "_i_d_card_printer_8java.html", [
      [ "IDCardPrinter", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer.html", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer" ]
    ] ],
    [ "IDContent.java", "_i_d_content_8java.html", [
      [ "IDContent", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content.html", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_content" ]
    ] ],
    [ "Printer.java", "_printer_8java.html", [
      [ "Printer", "classswp_1_1bibjsf_1_1renderer_1_1_printer.html", "classswp_1_1bibjsf_1_1renderer_1_1_printer" ]
    ] ]
];