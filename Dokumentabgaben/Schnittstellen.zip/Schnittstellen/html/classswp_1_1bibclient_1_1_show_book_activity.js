var classswp_1_1bibclient_1_1_show_book_activity =
[
    [ "onCreate", "classswp_1_1bibclient_1_1_show_book_activity.html#a1478b7ac244a263544f8722825f541ea", null ],
    [ "onResume", "classswp_1_1bibclient_1_1_show_book_activity.html#a297ae9a91d1a698d0f4ca1f2e3779e50", null ]
];