var files =
[
    [ "bibclient", "dir_765c23345e8fb9962bda0fc44ad5f25d.html", "dir_765c23345e8fb9962bda0fc44ad5f25d" ],
    [ "bibcommon", "dir_01cbecbbd95b24aaa29b2c2d4a8c01a0.html", "dir_01cbecbbd95b24aaa29b2c2d4a8c01a0" ],
    [ "bibjsf", "dir_cc378ef0ea407ebeb1c3bd7e2989a79c.html", "dir_cc378ef0ea407ebeb1c3bd7e2989a79c" ]
];