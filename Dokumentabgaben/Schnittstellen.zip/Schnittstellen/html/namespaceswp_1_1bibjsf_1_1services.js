var namespaceswp_1_1bibjsf_1_1services =
[
    [ "BibServices", "classswp_1_1bibjsf_1_1services_1_1_bib_services.html", "classswp_1_1bibjsf_1_1services_1_1_bib_services" ]
];