var classswp_1_1bibjsf_1_1presentation_1_1_change_reader_form =
[
    [ "ChangeReaderForm", "classswp_1_1bibjsf_1_1presentation_1_1_change_reader_form.html#a6544e61606be49423875e51da98d142a", null ],
    [ "edit", "classswp_1_1bibjsf_1_1presentation_1_1_change_reader_form.html#a0e166630e496046c31c10155780e4fff", null ],
    [ "save", "classswp_1_1bibjsf_1_1presentation_1_1_change_reader_form.html#ab3deb4d6e3a8eb9d5e9f3bde25befa24", null ]
];