var classswp_1_1bibjsf_1_1presentation_1_1_add_librarian_form =
[
    [ "AddLibrarianForm", "classswp_1_1bibjsf_1_1presentation_1_1_add_librarian_form.html#a66c8a6829230368479e92238fd43a447", null ],
    [ "reset", "classswp_1_1bibjsf_1_1presentation_1_1_add_librarian_form.html#a62b9a9c4303cc98c5347ab3d42a89b97", null ],
    [ "save", "classswp_1_1bibjsf_1_1presentation_1_1_add_librarian_form.html#ad0c6be190af7691f6dd6ce70f0be4aef", null ]
];