var classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler =
[
    [ "AdministrationHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler.html#a24d25fc5fa8cdfad983f2c535d661d12", null ],
    [ "backupDB", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler.html#ac254c17315e200a3b82f92561d80f980", null ],
    [ "resetDB", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler.html#a3c51c22ee7063d6f0508402e1810b249", null ],
    [ "restoreDB", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler.html#a76751ba712eb3d68a9b6efbb821c134c", null ]
];