var classswp_1_1bibclient_1_1_list_medium_activity =
[
    [ "onCreate", "classswp_1_1bibclient_1_1_list_medium_activity.html#a60380a2074c8c9bec2cb4d394f98bd10", null ]
];