var namespaceswp_1_1bibjsf_1_1tests =
[
    [ "BookTagPrinterTest", "classswp_1_1bibjsf_1_1tests_1_1_book_tag_printer_test.html", "classswp_1_1bibjsf_1_1tests_1_1_book_tag_printer_test" ],
    [ "CSVReaderTest", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test" ],
    [ "IDCardPrinterTest", "classswp_1_1bibjsf_1_1tests_1_1_i_d_card_printer_test.html", "classswp_1_1bibjsf_1_1tests_1_1_i_d_card_printer_test" ],
    [ "ISBNGoogleSearchTest", "classswp_1_1bibjsf_1_1tests_1_1_i_s_b_n_google_search_test.html", "classswp_1_1bibjsf_1_1tests_1_1_i_s_b_n_google_search_test" ]
];