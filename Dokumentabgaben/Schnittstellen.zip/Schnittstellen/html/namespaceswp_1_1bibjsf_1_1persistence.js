var namespaceswp_1_1bibjsf_1_1persistence =
[
    [ "Data", "classswp_1_1bibjsf_1_1persistence_1_1_data.html", "classswp_1_1bibjsf_1_1persistence_1_1_data" ],
    [ "Persistence", "interfaceswp_1_1bibjsf_1_1persistence_1_1_persistence.html", "interfaceswp_1_1bibjsf_1_1persistence_1_1_persistence" ]
];