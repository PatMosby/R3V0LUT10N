var classswp_1_1bibjsf_1_1exception_1_1_no_such_book_exists_exception =
[
    [ "NoSuchBookExistsException", "classswp_1_1bibjsf_1_1exception_1_1_no_such_book_exists_exception.html#afc96a3cd423175f2a8dd159fbf42a6b3", null ],
    [ "NoSuchBookExistsException", "classswp_1_1bibjsf_1_1exception_1_1_no_such_book_exists_exception.html#ad09069763cad731da1f6c955e2a3b91c", null ]
];