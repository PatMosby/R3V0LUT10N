var classswp_1_1bibjsf_1_1exception_1_1_data_source_exception =
[
    [ "DataSourceException", "classswp_1_1bibjsf_1_1exception_1_1_data_source_exception.html#a0af1a18945d18e1cb55092e8a9ed1914", null ],
    [ "DataSourceException", "classswp_1_1bibjsf_1_1exception_1_1_data_source_exception.html#aa85563b1be8031747860aa0a9aeac0ae", null ]
];