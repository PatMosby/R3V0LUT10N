var namespaceswp_1_1bibjsf_1_1exception =
[
    [ "BibJSFException", "classswp_1_1bibjsf_1_1exception_1_1_bib_j_s_f_exception.html", "classswp_1_1bibjsf_1_1exception_1_1_bib_j_s_f_exception" ],
    [ "BookAlreadyExistsException", "classswp_1_1bibjsf_1_1exception_1_1_book_already_exists_exception.html", "classswp_1_1bibjsf_1_1exception_1_1_book_already_exists_exception" ],
    [ "BusinessElementAlreadyExistsException", "classswp_1_1bibjsf_1_1exception_1_1_business_element_already_exists_exception.html", "classswp_1_1bibjsf_1_1exception_1_1_business_element_already_exists_exception" ],
    [ "DataSourceException", "classswp_1_1bibjsf_1_1exception_1_1_data_source_exception.html", "classswp_1_1bibjsf_1_1exception_1_1_data_source_exception" ],
    [ "NoSuchBookExistsException", "classswp_1_1bibjsf_1_1exception_1_1_no_such_book_exists_exception.html", "classswp_1_1bibjsf_1_1exception_1_1_no_such_book_exists_exception" ]
];