var classswp_1_1bibclient_1_1_medium_adapter =
[
    [ "MediumAdapter", "classswp_1_1bibclient_1_1_medium_adapter.html#ac12005761bd4685a5ddd87ab3e466c06", null ],
    [ "getView", "classswp_1_1bibclient_1_1_medium_adapter.html#a097ab0b614b14bc1f753d3f630584a80", null ]
];