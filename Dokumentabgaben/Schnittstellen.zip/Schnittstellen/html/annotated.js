var annotated =
[
    [ "swp", "namespaceswp.html", "namespaceswp" ]
];