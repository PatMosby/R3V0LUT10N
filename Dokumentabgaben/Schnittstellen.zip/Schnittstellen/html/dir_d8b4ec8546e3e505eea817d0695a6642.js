var dir_d8b4ec8546e3e505eea817d0695a6642 =
[
    [ "bibclient", "dir_387d1483f120591b022e71efc77a6eb3.html", "dir_387d1483f120591b022e71efc77a6eb3" ]
];