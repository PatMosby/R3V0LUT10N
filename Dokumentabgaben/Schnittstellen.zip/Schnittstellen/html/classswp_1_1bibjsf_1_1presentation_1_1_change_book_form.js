var classswp_1_1bibjsf_1_1presentation_1_1_change_book_form =
[
    [ "edit", "classswp_1_1bibjsf_1_1presentation_1_1_change_book_form.html#aad2b405b29f201f3aaae481357128361", null ],
    [ "getSelectable", "classswp_1_1bibjsf_1_1presentation_1_1_change_book_form.html#aaa813b3becb3a706c6f43acc0823e6f9", null ],
    [ "save", "classswp_1_1bibjsf_1_1presentation_1_1_change_book_form.html#a0062f9e370c0d3f3814a28ffa0661d76", null ]
];