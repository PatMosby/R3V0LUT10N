var classswp_1_1bibcommon_1_1_audiobook =
[
    [ "Audiobook", "classswp_1_1bibcommon_1_1_audiobook.html#a3a04fa8bd5ae3aeea35dcb3c2041cd71", null ],
    [ "Audiobook", "classswp_1_1bibcommon_1_1_audiobook.html#ae756e2aa4895ea8cb30e2845ab3e2332", null ],
    [ "getMedia", "classswp_1_1bibcommon_1_1_audiobook.html#a5420c50ba707027f93eccc151b4d1e40", null ],
    [ "getPlayTime", "classswp_1_1bibcommon_1_1_audiobook.html#a1edee298c30c8b38b34bddbde8f56b01", null ],
    [ "getPublisher", "classswp_1_1bibcommon_1_1_audiobook.html#aaf6b87e4c965d4f539af0149bcce0404", null ],
    [ "setMedia", "classswp_1_1bibcommon_1_1_audiobook.html#ae73d7ad28ca5417b90a2747dbee6f6f3", null ],
    [ "setPlayTime", "classswp_1_1bibcommon_1_1_audiobook.html#a9fe77bc44a7b81205fad41e2c36e3b3c", null ],
    [ "setPublisher", "classswp_1_1bibcommon_1_1_audiobook.html#a8b2d9c2f3e21f7c9e6652d5a9de0f6de", null ]
];