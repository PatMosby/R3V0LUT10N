var dir_27f4fe4d5157cb47b1850a458e154845 =
[
    [ "Data.java", "_data_8java.html", [
      [ "Data", "classswp_1_1bibjsf_1_1persistence_1_1_data.html", "classswp_1_1bibjsf_1_1persistence_1_1_data" ]
    ] ],
    [ "package-info.java", "bibjsf_2src_2main_2java_2swp_2bibjsf_2persistence_2package-info_8java.html", null ],
    [ "Persistence.java", "_persistence_8java.html", [
      [ "Persistence", "interfaceswp_1_1bibjsf_1_1persistence_1_1_persistence.html", "interfaceswp_1_1bibjsf_1_1persistence_1_1_persistence" ]
    ] ]
];