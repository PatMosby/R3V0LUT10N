var classswp_1_1bibjsf_1_1presentation_1_1_reader_table =
[
    [ "ReaderTable", "classswp_1_1bibjsf_1_1presentation_1_1_reader_table.html#ac2dab88a5916f27fb92cc601433e3154", null ],
    [ "getContent", "classswp_1_1bibjsf_1_1presentation_1_1_reader_table.html#a1b3b932b05bcd78a19cdee0c0f8e5fdf", null ],
    [ "getPrinter", "classswp_1_1bibjsf_1_1presentation_1_1_reader_table.html#a6374ec0ba6b23b8aa3512334ba8f49b4", null ]
];