var classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test =
[
    [ "testCorrectTableWithEmptyColumns", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a8ee510ac2ca40fdccac1a41f4c551c1b", null ],
    [ "testEmptyTableNoHeader", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a0bea7f89825c8f05882a40ce1bccf5aa", null ],
    [ "testEmptyTableWithHeader", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#afa2a84d3cb8c4caa2f548e8a462d07d3", null ],
    [ "testFilledCorrectTable", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a1d9e214ac3c6132bf375577fb17eb711", null ],
    [ "testInput1", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#ab3dbd9b4d5ff6d0b9b6adb6c37c3fa90", null ],
    [ "testInput2", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#acb5357df1160daa34a05984e25f68b5d", null ],
    [ "testInput3", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a206e42c2fe7f93df6e8eb696d483e202", null ],
    [ "testInput4", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a2f2a98e6e1abf7451f6dad3357d4ad35", null ],
    [ "testInput5", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a01f2a31e69fad1f7135e15c3d381bb5b", null ],
    [ "testInput6", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a5b58492a53873c1d84e47c17258f87df", null ],
    [ "testInput7", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a2cdb0f533a446a9d4a34353ac55023da", null ],
    [ "testInput8", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#a51960f910455f8df817fc855804befb3", null ],
    [ "testMixedQuoteValues", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#ad2ac1efb2d7fb516e080b0f01c6a5545", null ],
    [ "testTableWithOneColumn", "classswp_1_1bibjsf_1_1tests_1_1_c_s_v_reader_test.html#aee8da709933c852dd01eee0d5a213cf6", null ]
];