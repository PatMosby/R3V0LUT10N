var classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer =
[
    [ "IDCardPrinter", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer.html#a577a6134a502af204483cff7a8d14d6f", null ],
    [ "numberOfCardsPerColumn", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer.html#a8a34c2f5a2722c2d8311ed2f01593b3a", null ],
    [ "numberOfCardsPerRow", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer.html#a124daaf7f887704cf94a2e85d02ef937", null ],
    [ "printCard", "classswp_1_1bibjsf_1_1renderer_1_1_i_d_card_printer.html#a21594c456832a534d95b36e97c12d097", null ]
];