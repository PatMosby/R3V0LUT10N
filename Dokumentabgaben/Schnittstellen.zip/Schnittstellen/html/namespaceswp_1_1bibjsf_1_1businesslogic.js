var namespaceswp_1_1bibjsf_1_1businesslogic =
[
    [ "AdministrationHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_administration_handler" ],
    [ "BookHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_book_handler" ],
    [ "BorrowHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_borrow_handler" ],
    [ "BusinessHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_handler" ],
    [ "BusinessObjectHandler< BusinessObject >", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_business_object_handler_3_01_business_object_01_4" ],
    [ "ReaderHandler", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler.html", "classswp_1_1bibjsf_1_1businesslogic_1_1_reader_handler" ]
];