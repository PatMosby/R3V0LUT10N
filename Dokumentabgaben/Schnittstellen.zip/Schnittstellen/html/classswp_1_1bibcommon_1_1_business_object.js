var classswp_1_1bibcommon_1_1_business_object =
[
    [ "getId", "classswp_1_1bibcommon_1_1_business_object.html#a3cd758f80157df399062efdc52c783d8", null ],
    [ "hasId", "classswp_1_1bibcommon_1_1_business_object.html#a21841c36cfd9192d69c5c9d35c1b8d3b", null ],
    [ "setId", "classswp_1_1bibcommon_1_1_business_object.html#a349f24c168349c32f314834643e94a07", null ],
    [ "id", "classswp_1_1bibcommon_1_1_business_object.html#a9a4f550daec55a6e97fbefbab60cf412", null ]
];