var namespaceswp =
[
    [ "bibclient", "namespaceswp_1_1bibclient.html", "namespaceswp_1_1bibclient" ],
    [ "bibcommon", "namespaceswp_1_1bibcommon.html", "namespaceswp_1_1bibcommon" ],
    [ "bibjsf", "namespaceswp_1_1bibjsf.html", "namespaceswp_1_1bibjsf" ]
];