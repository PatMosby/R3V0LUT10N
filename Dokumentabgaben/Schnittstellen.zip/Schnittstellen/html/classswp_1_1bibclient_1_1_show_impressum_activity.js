var classswp_1_1bibclient_1_1_show_impressum_activity =
[
    [ "onCreate", "classswp_1_1bibclient_1_1_show_impressum_activity.html#a770aab436474f7f61595519cbde0e282", null ]
];